package com.test.futbol5;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import busqueda.dto.Evento;
import busqueda.jdbc.BusquedaDAO;
import busqueda.jdbc.BusquedaIF;

import eventos.jdbc.ModEventosDAO;

public class testCreacion {
	private ModEventosDAO dao=new ModEventosDAO();
	int id;
	
	@Before
	public void setUp() throws Exception {
		String nombre = "Evento45";
		int codorganizador =1;
		String fecha = "2015-01-15";
		String hora= "19:00:00";
		int codcancha = 2;
		id=dao.registrarEvento(nombre, codorganizador, fecha, hora, codcancha);


	}

	@Test
	public void test() {
		assertEquals("Fall� Nombre",dao.getEvento2().getNombre(),"Evento45");
		assertEquals("Fall� Organizador",dao.getEvento2().getCodOrg(),1);
		assertEquals("Fall� Fecha",dao.getEvento2().getFecha(),"2015-01-15 19:00:00");
		assertEquals("Fall� Cancha",dao.getEvento2().getIdCan(),2);
	}

}

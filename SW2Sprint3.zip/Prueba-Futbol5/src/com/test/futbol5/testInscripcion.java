package com.test.futbol5;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import eventos.jdbc.InscripUsDAO;

public class testInscripcion {
	private InscripUsDAO dao=new InscripUsDAO();
	int cantInicial;
	//Se probar� que aumenta en uno la cantidad de participantes est�ndar
	@Before
	public void setUp() throws Exception {
		cantInicial=dao.getEvento().getCantP();
		int coduser=2;
		int cod_evento=1;
		String tipo="ESTANDAR";
		dao.registrarInscrip(coduser,cod_evento,tipo);
	}

	@Test
	public void test() {
		assertEquals("Fall� la inscripci�n",dao.getEvento().getCantP(),cantInicial+1);
	}

}

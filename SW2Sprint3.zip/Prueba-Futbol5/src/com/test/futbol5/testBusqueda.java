package com.test.futbol5;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import busqueda.dto.Evento;
import busqueda.jdbc.BusquedaDAO;
import busqueda.jdbc.BusquedaIF;

public class testBusqueda {
	BusquedaIF d = new BusquedaDAO();
	List <Evento> lista;
	@Before
	public void setUp() throws Exception {
		String distrito ="San Miguel";
		lista=d.buscarEventos(distrito);
	}

	@Test
	public void test() {
		for(int i=0;i<lista.size();i++){
			assertEquals("Fall� la busqueda",lista.get(i).getDistrito(),("San Miguel").toUpperCase());
		}
	}

}

package busqueda.dto;

public class Cancha {

	private int codCancha;
	private String nombreCancha;
	private String dirCancha;
	private int codDistrito;
	private int codEmpresa;
	
	
	
	
	public Cancha() {
		super();
	}


	public Cancha(int codCancha, String nombreCancha, String dirCancha,
			int codDistrito, int codEmpresa) {
		super();
		this.codCancha = codCancha;
		this.nombreCancha = nombreCancha;
		this.dirCancha = dirCancha;
		this.codDistrito = codDistrito;
		this.codEmpresa = codEmpresa;
	}
	
	
	public int getCodCancha() {
		return codCancha;
	}
	public void setCodCancha(int codCancha) {
		this.codCancha = codCancha;
	}
	public String getNombreCancha() {
		return nombreCancha;
	}
	public void setNombreCancha(String nombreCancha) {
		this.nombreCancha = nombreCancha;
	}
	public String getDirCancha() {
		return dirCancha;
	}
	public void setDirCancha(String dirCancha) {
		this.dirCancha = dirCancha;
	}
	public int getCodDistrito() {
		return codDistrito;
	}
	public void setCodDistrito(int codDistrito) {
		this.codDistrito = codDistrito;
	}
	public int getCodEmpresa() {
		return codEmpresa;
	}
	public void setCodEmpresa(int codEmpresa) {
		this.codEmpresa = codEmpresa;
	}
	
	
	
	
}

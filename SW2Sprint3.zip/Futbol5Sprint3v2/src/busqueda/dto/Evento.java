package busqueda.dto;

public class Evento {
	
	private int codEvento;
	private String nombre;
	private String organizador;
	private int codOrg;
	private String fecha;
	private int idCan;
	private Cancha can;
	private String distrito;
	private int cantP;
	private int cantS;

	
	public Evento() {
		super();
	}


	public Evento(int codEvento, String organizador, String fecha,
			busqueda.dto.Cancha can) {
		super();
		this.codEvento = codEvento;
		this.organizador = organizador;
		this.fecha = fecha;
		this.can = can;
		this.cantP=0;
		this.cantS=0;
	}


	public int getCodEvento() {
		return codEvento;
	}


	public void setCodEvento(int codEvento) {
		this.codEvento = codEvento;
	}


	public String getOrganizador() {
		return organizador;
	}


	public void setOrganizador(String organizador) {
		this.organizador = organizador;
	}


	public String getFecha() {
		return fecha;
	}


	public void setFecha(String fecha) {
		this.fecha = fecha;
	}


	public Cancha getCan() {
		return can;
	}


	public void setCan(Cancha can) {
		this.can = can;
	}


	public int getCantP() {
		return cantP;
	}


	public void setCantP(int cantP) {
		this.cantP = cantP;
	}


	public int getCantS() {
		return cantS;
	}


	public void setCantS(int cantS) {
		this.cantS = cantS;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getDistrito() {
		return distrito;
	}


	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}


	public int getIdCan() {
		return idCan;
	}


	public void setIdCan(int idCan) {
		this.idCan = idCan;
	}


	public int getCodOrg() {
		return codOrg;
	}


	public void setCodOrg(int codOrg) {
		this.codOrg = codOrg;
	}
	
	public void agregarP(){
		cantP++;
	}
	public void agregarS(){
		cantS++;
	}
	
	
	
	


	
	

}

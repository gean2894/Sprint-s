package busqueda.jdbc;

import java.util.List;

import busqueda.dto.Cancha;
import busqueda.dto.Evento;

public class Busqueda implements BusquedaIF {

	public List<Evento> buscarEventos(String distrito) {
		// TODO Auto-generated method stub
		return null;
	}

	public Evento buscarEvento(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Cancha buscarCancha(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}

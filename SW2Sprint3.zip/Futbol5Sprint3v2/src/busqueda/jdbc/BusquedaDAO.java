package busqueda.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import busqueda.dto.Cancha;
import busqueda.dto.Evento;


import utils.Database;

public class BusquedaDAO implements BusquedaIF {
	
	public List<Evento> buscarEventos(String distrito) {
		
		List<Evento> result=new ArrayList<Evento>();
		String sql= " select cod_evento,nombre,cod_org,fecha,cod_cancha,distrito " +
				"FROM evento where distrito = UPPER(?) ";	
				
		PreparedStatement pstmt = null;
        Connection con = Database.getConnection();
        ResultSet rs=null;
        Evento ev=null;
        try {
           
        	pstmt=con.prepareStatement(sql);
        	pstmt.setString(1, distrito);
        	System.out.println(sql);
            rs=pstmt.executeQuery();
            int cont=0;
            
            while(rs.next()) {
            	ev=new Evento();
               	ev.setCodEvento(rs.getInt(1));
            	ev.setNombre(rs.getString(2));
            	ev.setCodOrg(rs.getInt(3));
            	ev.setFecha(rs.getString(4));
            	ev.setIdCan(rs.getInt(5));
            	ev.setDistrito(rs.getString(6));
            	result.add(ev);
            	cont++;
            	System.out.println(cont);
            }
            System.out.println("Resultado: " + cont);
 
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        	try {
				pstmt.close();
	        	
	        	Database.close(con);
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
        
        }
        return result;


	}

	@Override
	public Evento buscarEvento(int id) {

		
		String sql= "select c.nombre_cancha, c.direccion,e.cod_cancha,e.cod_org, e.nombre,date_format(fecha,'%Y-%m-%d %H:%i:%s')," + 
		" u.nombre, u.apellido from evento e INNER JOIN cancha c ON"+
				" e.cod_cancha=c.cod_cancha INNER JOIN usuario u ON e.cod_org=u.cod_user "+
		"WHERE e.cod_evento = ?";
		
		/* String sq2 = "SELECT e.NOMBRE_ESTABLECIMIENTO, t.NOMBRE_TIPO_EST, e.CATEGORIA, " +
		"e.QUINTIL, p.NOMBRE_PRESUPUESTO, i.NOMBRE_INSTITUCION, d.NOMBRE_DIRESA, " + 
				"e.ID_DEP, e.DISTRITO FROM ESTABLECIMIENTO_SALUD e INNER JOIN TIPO_ESTABLECIMIENTO "+
		"t ON e.ID_TIPO= t.ID_TIPO_EST INNER JOIN INSTITUCION i ON "+
				"e.ID_INSTITUCION = i.ID_INSTITUCION INNER JOIN PRESUPUESTO p "+
		"ON e.ID_PRESUPUESTO= p.ID_PRESUPUESTO INNER JOIN DIRESA d ON e.ID_DIRESA=d.ID_DIRESA"+
				" WHERE e.ID_ESTABLECIMIENTO = ?";
		*/
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
	    Connection con = Database.getConnection();
	    
	    Evento event = new Evento();
	    Cancha cancha = new Cancha();
	    try {
	        pstmt = con.prepareStatement(sql);
	        pstmt.setInt(1,id);
	        rs = pstmt.executeQuery();
	        if (rs.next()) {
	        	// 1 nombre de cancha, 2 direccion de cancha
	        	// 3 nombre de evento, 4 fecha de evento
	        	// 5 nombre de organizador
	        	// 6 apellido de organizador
	        	cancha.setNombreCancha(rs.getString(1));
	        	cancha.setDirCancha(rs.getString(2));
	        	event.setIdCan(Integer.parseInt(rs.getString(3)));
	        	event.setCodOrg(Integer.parseInt(rs.getString(4)));
	        	event.setNombre(rs.getString(5));
	        	System.out.println(rs.getString(5));
	        	event.setFecha(rs.getString(6));
	        	event.setCan(cancha);
	        	event.setOrganizador(rs.getString(7) + " " + rs.getString(8));
	        	event.setCodEvento(id);
	        	
	        	
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	    	try {
				pstmt.close();
	        	rs.close();
	        	Database.close(con);
			} catch (SQLException e) {
			}
	    }

	    return event;
	}

	@Override
	public Cancha buscarCancha(int id) {
		
		return null;
	}


	
	/*
	@Override
	public List<Comentario> listarComentarios(int id) {
		
		
		List<Comentario> l = new ArrayList<Comentario>();
		String sql = "SELECT * FROM COMENTARIO WHERE ID_EST = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
        Connection con = Database.getConnection();
        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1,id);
            rs = pstmt.executeQuery();
            while (rs.next() )  { 
            	Comentario co = new Comentario();
            	co.setAgua(rs.getString(4));
            	co.setClima(rs.getString(3));
            	co.setComentario(rs.getString(7));
            	co.setLuz(rs.getString(6));
            	co.setTelef(rs.getString(5));
            	co.setViaAcceso(rs.getString(2));
            	
            	System.out.println(co.getComentario());
                l.add(co);
            }
        } catch (Exception ex) {
            System.out.println("Error en getAllAlumnos() -->" + ex.getMessage());
        } finally {
        	try {
				pstmt.close();
	        	rs.close();
	        	Database.close(con);
			} catch (SQLException e) {
			}
        }
		return l;
		

       
	} */

}

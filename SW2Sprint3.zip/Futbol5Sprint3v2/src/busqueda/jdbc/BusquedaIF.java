package busqueda.jdbc;

import java.util.List;

import busqueda.dto.Cancha;
import busqueda.dto.Evento;

public interface BusquedaIF {
	
	public List<Evento> buscarEventos(String distrito);
	public Evento buscarEvento(int id);
	public Cancha buscarCancha(int id);
	//public List<Cancha> listarCanchas(int distrito);
	//public String buscarEmpresa(int cod);


}

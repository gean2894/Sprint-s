package eventos.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;

import utils.Database;

import busqueda.dto.Cancha;
import busqueda.dto.Evento;
import busqueda.jdbc.BusquedaDAO;
import busqueda.jdbc.BusquedaIF;
import eventos.dto.Detalle;

public class ModEventosDAO implements ModEventosIF {
	static Evento evento=new Evento();
	int cod;
	

	public int generarId(){
		Random r = new Random();
		int newId=r.nextInt(10000);
		String sql="select evento.cod_evento from evento where cod_evento=?";
		int nuevoId=0;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = Database.getConnection();

		        try {
		            pstmt = con.prepareStatement(sql);
		            pstmt.setInt(1, newId);
		            rs = pstmt.executeQuery();
		            if (rs.next())  { 
		            	int idB=Integer.parseInt(rs.getString(1));
		            	if(newId==idB){
		            		nuevoId=0;
		            	}else {
		            		nuevoId=newId;
						}
		            		
		            } else {
		            	nuevoId=newId;
		            }
		        } catch (Exception ex) {
		            System.out.println("Error en autenticacion() -->" + ex.getMessage());
		        } finally {
		        	try {
						pstmt.close();
			        	rs.close();
			        	Database.close(con);
					} catch (SQLException e) {
					}
		        }
				return nuevoId;
	}
	public int registrarEvento(String nombre, int codorganizador,
			String fecha,String hora, int codCancha) {
		int newId=0;
		while (newId==0){
		 newId=generarId();
		}
		String sql="INSERT INTO `evento` (`cod_evento`,`nombre`,`cod_org`,`fecha`,`cod_cancha`)" +
				" values (?,?,?,timestamp(?),?)";
		int rs;
		PreparedStatement pstmt = null;
		Connection con = Database.getConnection();

		        try {
		        pstmt = con.prepareStatement(sql);
		        pstmt.setInt(1, newId);
		        evento.setCodEvento(newId);
		        cod=newId;
		 	    pstmt.setString(2, nombre);
		 	    pstmt.setInt(3,codorganizador);
		 	    pstmt.setString(4, fecha+" "+hora);
			    pstmt.setInt(5, codCancha);
		        rs = pstmt.executeUpdate();
		        
		        sql="UPDATE EVENTO C INNER JOIN CANCHA A 	ON A.cod_cancha=C.cod_cancha " +
		        		" INNER JOIN DISTRITO B ON A.cod_distrito=B.cod_distrito " + 
		        		" SET c.distrito = b.nom_distrito WHERE cod_evento=? ";
		            pstmt = con.prepareStatement(sql);
		            pstmt.setInt(1, newId);
		            rs = pstmt.executeUpdate();
		        } catch (Exception ex) {
		            System.out.println("Error en autenticacion MODEVENTOSDAO() -->" + ex.getMessage());
		        } finally {
		        	try {
						pstmt.close();
			        	Database.close(con);
					} catch (SQLException e) {
						System.out.println(e.getMessage());
					}
		        }
		return newId;

	}
	public Evento getEvento2() {
		 evento=new BusquedaDAO().buscarEvento(cod);
		 return evento;
	}
	public Evento getEvento() {
		 return evento;
	}
	public void setEvento(Evento evento) {
		ModEventosDAO.evento = evento;
	}
	public void registrarOrganizador(){
		evento.agregarP();
		new InscripUsDAO().registrarInscrip(evento.getCodOrg(), evento.getCodEvento(), "EST�NDAR");
	}

}

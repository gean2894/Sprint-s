package eventos.jdbc;

import java.util.List;

import eventos.dto.Detalle;
import busqueda.dto.Cancha;


public interface ModEventosIF {
	
	public int generarId();
	public int registrarEvento(String nombre,int codorganizador,String fecha,String hora, int codCancha);

}

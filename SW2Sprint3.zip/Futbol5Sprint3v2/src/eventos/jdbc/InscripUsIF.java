package eventos.jdbc;

public interface InscripUsIF {

	public void registrarInscrip(int user,int evento,String tipo);
	public boolean busquedaPlaza(int evento);

}

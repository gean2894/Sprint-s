package eventos.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import busqueda.dto.Cancha;
import busqueda.dto.Evento;
import busqueda.jdbc.BusquedaDAO;
import utils.Database;

public class InscripUsDAO implements InscripUsIF {
	static Evento e=new Evento();
	

	@Override
	public void registrarInscrip(int user, int evento, String tipo) {
		
		
		String sql="INSERT INTO `detalle_part` (`cod_user`,`cod_evento`,`tipo`)" +
				" values (?,?,?)";
		int rs;
		PreparedStatement pstmt = null;
		Connection con = Database.getConnection();

		        try {
		        pstmt = con.prepareStatement(sql);
		        pstmt.setInt(1, user);
		 	    pstmt.setInt(2, evento);
		 	    pstmt.setString(3, tipo);
		        rs = pstmt.executeUpdate();
		        if(tipo.equals("SOLIDARIO")){
		        	e.agregarS();
		        }else{
		        	e.agregarP();
		        }
		        

		        } catch (Exception ex) {
		            System.out.println("Error en autenticacion() EN INSCRIP -->" + ex.getMessage());
		        } finally {
		        	try {
						pstmt.close();
			        	Database.close(con);
					} catch (SQLException e) {
						System.out.println(e.getMessage());
					}
		        }
	
	}

	@Override
	public boolean busquedaPlaza(int evento) {

		String sql= "SELECT sum(cod_user) FROM futbol5.detalle_part where tipo='ESTANDAR' AND cod_evento=?";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
	    Connection con = Database.getConnection();

	    int cant =0;
	    try {
	        pstmt = con.prepareStatement(sql);
	        pstmt.setInt(1,evento);
	        rs = pstmt.executeQuery();
	        if (rs.next()) {
	        	cant= rs.getInt(1);       	
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	    	try {
				pstmt.close();
	        	rs.close();
	        	Database.close(con);
			} catch (SQLException e) {
			}
	    }
	    
	    if(cant>=10){
	    	return true;
	    }else{
		    return false;
	    }

	}
	
	public Evento getEvento2(int newId) {
		 e=new BusquedaDAO().buscarEvento(newId);
		 return e;
	}
	public Evento getEvento() {
		 return e;
	}
	public void setEvento(Evento evento) {
		InscripUsDAO.e = evento;
	}

}

package eventos.dto;

public class Usuario {

}

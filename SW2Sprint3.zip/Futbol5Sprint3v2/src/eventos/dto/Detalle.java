package eventos.dto;

public class Detalle {
 private int codusuario;
 private int codevento;
 private String tipo;
 
public Detalle() {
	super();
}

public Detalle(int codusuario, int codevento, String tipo) {
	super();
	this.codusuario = codusuario;
	this.codevento = codevento;
	this.tipo = tipo;
}

public int getCodusuario() {
	return codusuario;
}

public void setCodusuario(int codusuario) {
	this.codusuario = codusuario;
}

public int getCodevento() {
	return codevento;
}

public void setCodevento(int codevento) {
	this.codevento = codevento;
}

public String getTipo() {
	return tipo;
}

public void setTipo(String tipo) {
	this.tipo = tipo;
}
 
 


 
}

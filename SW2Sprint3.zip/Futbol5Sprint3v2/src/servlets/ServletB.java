package servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import busqueda.dto.Evento;
import busqueda.jdbc.BusquedaDAO;
import busqueda.jdbc.BusquedaIF;

/**
 * Servlet implementation class ServletB
 */
public class ServletB extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletB() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				//PASO 1:
				HttpSession ses = request.getSession(true);
						

				// PASO 2: 
				String departamento = request.getParameter("List1");
				String ciudad = request.getParameter("List2");
				String distrito = request.getParameter("List3");
						
				System.out.println(departamento + ciudad + distrito );
				// PASO 3: alguna logica
				
				 /* List <String> parametros= new ArrayList<String>();
				
				 parametros.add(tipoEst);
				 parametros.add(inst);
				 parametros.add(cat);
				 parametros.add(quintil);
				*/
				BusquedaIF d = new BusquedaDAO();
				List <Evento> lista=d.buscarEventos(distrito);
				
				
				
				// PASO 4:
				
				
				for (int i=0;i<lista.size();i++){
					System.out.println(lista.get(i).getCodEvento());
				}
				
				ses.setAttribute("lista", lista);
				ses.setAttribute("total", lista.size());
				
				
						
				// PASO 5: 
				RequestDispatcher rd = request.getRequestDispatcher("/busqueda/resultados.jsp");
				rd.forward(request, response);
	}

}

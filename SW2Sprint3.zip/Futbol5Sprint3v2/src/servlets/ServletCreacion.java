package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import eventos.dto.Detalle;
import eventos.jdbc.ModEventosDAO;
import busqueda.dto.Cancha;
import busqueda.dto.Evento;
import busqueda.jdbc.BusquedaDAO;
import busqueda.jdbc.BusquedaIF;

/**
 * Servlet implementation class ServletCreacion
 */
public class ServletCreacion extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BusquedaIF dao1 = new BusquedaDAO();
	private ModEventosDAO dao=new ModEventosDAO();


    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletCreacion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession ses = request.getSession(true);

		// PASO 2: 
		String nombre = (String)request.getParameter("nombre");
		int codorganizador = Integer.parseInt((String)request.getParameter("codorg"));
		String fecha = (String)request.getParameter("fecha").trim();
		String hora= (String)request.getParameter("hora");
		int codcancha = Integer.parseInt((String)request.getParameter("codcancha"));


		
		// PASO 3: alguna logica
		int id=dao.registrarEvento(nombre, codorganizador, fecha, hora, codcancha);
    	// 1 nombre de cancha, 2 direccion de cancha
    	// 3 nombre de evento, 4 fecha de evento
    	// 5 nombre de organizador
    	// 6 apellido de organizador

		//registrarlo como participante
		//dao.registrarOrganizador();

		// PASO 4:
		
		Evento evento =dao1.buscarEvento(id);
		

		ses.setAttribute("nombrecancha", evento.getCan().getNombreCancha());
		ses.setAttribute("dircancha", evento.getCan().getDirCancha());
		ses.setAttribute("nombreevent", evento.getNombre());
		ses.setAttribute("fechaevent", evento.getFecha());
		ses.setAttribute("organizador", evento.getOrganizador());
	

		
		// PASO 5: 
		RequestDispatcher rd = request.getRequestDispatcher("/busqueda/evento.jsp");
		rd.forward(request, response);
	}

}

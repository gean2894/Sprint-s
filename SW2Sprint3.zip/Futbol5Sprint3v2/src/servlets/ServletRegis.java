package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import eventos.jdbc.InscripUsDAO;

/**
 * Servlet implementation class ServletRegis
 */
public class ServletRegis extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private InscripUsDAO dao=new InscripUsDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletRegis() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		

		
		HttpSession ses = request.getSession(true);

		// PASO 2: 
		String tipoReg = (String)request.getParameter("tipoUs");
		int usuario = Integer.parseInt((String)request.getParameter("codusuario"));
		int id= (int) ses.getAttribute("codevento");
		

		// PASO 3: alguna logica
		dao.registrarInscrip(usuario, id, tipoReg);


		// PASO 4:
		ses.setAttribute("registrado", "registrado"+id);
		
		// PASO 5: 
		RequestDispatcher rd = request.getRequestDispatcher("/busqueda/evento.jsp");
		rd.forward(request, response);
		
	}

}

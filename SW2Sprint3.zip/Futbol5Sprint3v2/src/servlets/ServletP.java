package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import eventos.jdbc.InscripUsDAO;
import busqueda.dto.Evento;
import busqueda.jdbc.BusquedaDAO;
import busqueda.jdbc.BusquedaIF;


/**
 * Servlet implementation class ServletP
 */
public class ServletP extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BusquedaIF dao = new BusquedaDAO();
	private InscripUsDAO dao1=new InscripUsDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletP() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession ses = request.getSession(true);

		// PASO 2: 
		int id= Integer.parseInt((String)request.getParameter("id"));

		// PASO 3: alguna logica
		Evento evento =dao.buscarEvento(id);
		
		boolean maximo = dao1.busquedaPlaza(id);

    	// 1 nombre de cancha, 2 direccion de cancha
    	// 3 nombre de evento, 4 fecha de evento
    	// 5 nombre de organizador
    	// 6 apellido de organizador


		// PASO 4:
		

		ses.setAttribute("maximo", maximo);
		ses.setAttribute("codevento", id);
		ses.setAttribute("nombrecancha", evento.getCan().getNombreCancha());
		ses.setAttribute("dircancha", evento.getCan().getDirCancha());
		ses.setAttribute("nombreevent", evento.getNombre());
		ses.setAttribute("fechaevent", evento.getFecha());
		ses.setAttribute("organizador", evento.getOrganizador());
	

		
		// PASO 5: 
		RequestDispatcher rd = request.getRequestDispatcher("/busqueda/evento.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
